# Contributing to AuraTracker

Thank you for your interest in improving AuraTracker! This document provides guidelines and instructions for contributing.

## Our Vision

AuraTracker exists to help people with seizure disorders and other health conditions track their health in a simple, private, and empowering way. We welcome contributions that:

- Improve accessibility and usability
- Enhance privacy and security
- Add features that help users manage their health better
- Improve documentation and onboarding
- Make the code more maintainable and testable

## Getting Started

1. **Fork the repository** on GitHub
2. **Clone your fork** locally
   ```bash
   git clone https://github.com/yourusername/auratracker.git
   cd auratracker
   ```
3. **Install dependencies**
   ```bash
   npm install
   ```
4. **Create a branch** for your work
   ```bash
   git checkout -b feature/your-feature-name
   ```

## Development Workflow

### Running Locally

```bash
npm run dev
```

Navigate to `http://localhost:3000` and test your changes.

### Code Standards

- **TypeScript**: All code should be properly typed
- **Formatting**: Use Prettier (configured in the project)
- **Linting**: Run `npm run lint` before committing
- **Testing**: Write tests for new features (Jest/React Testing Library setup coming)

### Commit Messages

Use clear, descriptive commit messages:

```
feat: add medication reminder notifications
fix: resolve timezone issue in daily logs
docs: update setup instructions
refactor: simplify seizure logging component
```

## Areas for Contribution

### 🎨 **Accessibility & UX**

Help make AuraTracker work for everyone:
- WCAG 2.1 AA compliance audits
- Screen reader testing
- Keyboard navigation improvements
- Simplifying health data entry flows
- Improving clarity of medical terminology

### 🔒 **Privacy & Security**

- Security audits and vulnerability reports (responsibly disclosed)
- Row-level security (RLS) policy review
- Data encryption improvements
- Privacy documentation updates

### ✨ **Features**

New tracking dimensions, visualizations, or insights are welcome. Before starting, open an issue to discuss:
- How it helps users manage their health
- Data privacy implications
- Design and UX considerations

Some ideas:
- Calendar heatmaps for pattern visualization
- Export-to-PDF for healthcare appointments
- Medication interaction checking
- Trend analysis and insights

### 📖 **Documentation**

- Deployment guides (Docker, cloud platforms, etc.)
- API documentation
- Setup tutorials for Supabase
- Troubleshooting guides
- Translation support

### 🧪 **Testing**

Set up and improve:
- Unit tests for utilities and components
- Integration tests for Supabase interactions
- E2E tests for critical user flows

## Pull Request Process

1. **Create a PR** with a clear title and description
2. **Reference any related issues** (`Fixes #123`)
3. **Describe your changes**: What, why, and how
4. **Test your work**: Manual testing + any automated tests
5. **Update docs** if needed
6. **Request review** from maintainers

### PR Template

```markdown
## Description
Brief summary of changes.

## Type of Change
- [ ] Bug fix
- [ ] New feature
- [ ] Documentation update
- [ ] Refactoring

## Testing
How did you test this?

## Checklist
- [ ] Code follows style guidelines
- [ ] Documentation updated
- [ ] No breaking changes
```

## Code Review Guidelines

When reviewing or receiving feedback:
- Be respectful and constructive
- Ask questions if something is unclear
- Focus on the code, not the person
- Suggest improvements, don't demand them

## Security & Privacy

**Never commit:**
- Supabase keys or secrets
- Personal health information
- API keys or tokens

Report security vulnerabilities **privately** by emailing `mattcardoza1812@gmail.com` with `[SECURITY]` in the subject.

## Reporting Issues

**Bug Reports** should include:
- Steps to reproduce
- Expected behavior
- Actual behavior
- Screenshots (if applicable)
- Environment (browser, device, OS)

**Feature Requests** should include:
- Problem it solves
- How it helps users
- Example use case

## Community Standards

- Be respectful and inclusive
- Assume good intentions
- Focus on constructive feedback
- Help others learn

Violations of our code of conduct will result in a warning or ban. See [CODE_OF_CONDUCT.md](./CODE_OF_CONDUCT.md).

## Questions?

Open an issue or start a discussion. We're here to help!

---

Thank you for making AuraTracker better. 💙
