import type { Config } from "tailwindcss"

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        ink: "#0C111C",
        ember: "#D97706",
        dawn: "#F97316",
        surface: "#1A1F2E",
        edge: "#374151",
        fog: "#9CA3AF",
        snow: "#E8EDF7",
      },
    },
  },
  plugins: [],
}
export default config
