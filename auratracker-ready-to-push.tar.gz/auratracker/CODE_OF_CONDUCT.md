# Code of Conduct

## Our Commitment

AuraTracker is committed to providing a welcoming and inspiring community for all. We are dedicated to creating an environment where every person feels valued and respected, regardless of background, identity, or experience.

## Our Values

We value:
- **Respect**: Treating all community members with dignity
- **Inclusivity**: Welcoming people from all backgrounds
- **Empathy**: Understanding the challenges of health management
- **Openness**: Creating space for diverse perspectives
- **Honesty**: Communicating authentically and constructively

## Expected Behavior

All community members are expected to:

- Be respectful and kind in all interactions
- Use welcoming and inclusive language
- Be open to constructive feedback
- Focus on what is best for the community
- Show empathy toward other community members
- Respect privacy and confidentiality (especially regarding health information)

## Unacceptable Behavior

The following is not tolerated:

- Harassment, bullying, or discrimination of any kind
- Offensive comments related to gender, identity, race, religion, disability, or health status
- Sharing others' private information without consent
- Threats or intimidation
- Spamming or off-topic content
- Any behavior that creates an unsafe or hostile environment

## Reporting Issues

If you witness or experience unacceptable behavior:

1. **Contact us** at `mattcardoza1812@gmail.com` with details
2. **Include context**: What happened, who was involved, when/where
3. **We will respond** within 48 hours

All reports are treated confidentially.

## Consequences

Violations of this code of conduct may result in:
- A warning or request to modify behavior
- Temporary muting or removal from discussions
- Permanent ban from the community

Our goal is to maintain a safe, welcoming community for everyone.

## Questions?

If you have questions about this code of conduct, please reach out. We're here to help maintain a positive community.

---

This code of conduct is adapted from the [Contributor Covenant](https://www.contributor-covenant.org/).
