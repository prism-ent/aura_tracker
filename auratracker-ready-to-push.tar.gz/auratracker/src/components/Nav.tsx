"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const links = [
  { label: "Home", href: "/" },
  { label: "Journal", href: "/journal" },
  { label: "Calendar", href: "/calendar" },
  { label: "Meds", href: "/meds" },
  { label: "Report", href: "/report" },
];

export default function Nav() {
  const pathname = usePathname();

  return (
    <nav className="bg-surface border-b border-edge sticky top-0 z-10">
      <div className="max-w-6xl mx-auto px-4 py-4 flex justify-between items-center">
        <Link href="/" className="font-display font-bold text-lg">
          aura
        </Link>
        <div className="flex gap-1">
          {links.map((link) => {
            const active = pathname === link.href;
            return (
              <Link
                key={link.href}
                href={link.href}
                className={`px-3 py-2 text-sm rounded transition ${
                  active
                    ? "bg-dawn text-ink font-semibold"
                    : "text-fog hover:text-snow hover:bg-ink"
                }`}
              >
                {link.label}
              </Link>
            );
          })}
        </div>
      </div>
    </nav>
  );
}
