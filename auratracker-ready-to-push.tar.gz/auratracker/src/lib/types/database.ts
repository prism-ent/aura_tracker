// Generated from Supabase schema
export interface SeizureEvent {
  id: string;
  user_id: string;
  occurred_at: string;
  duration_seconds?: number | null;
  seizure_type?: string | null;
  severity?: number | null;
  triggers?: string[] | null;
  notes?: string | null;
  created_at: string;
}

export interface DailyLog {
  id: string;
  user_id: string;
  log_date: string;
  sleep_hours?: number | null;
  sleep_quality?: number | null;
  stress?: number | null;
  mood?: number | null;
  pain?: number | null;
  took_meds?: boolean | null;
  caffeine?: boolean | null;
  alcohol?: boolean | null;
  exercise?: boolean | null;
  notes?: string | null;
  created_at: string;
}

export interface Medication {
  id: string;
  user_id: string;
  name: string;
  dose?: string | null;
  schedule?: string | null;
  active?: boolean | null;
  created_at: string;
}

export interface MedicationLog {
  id: string;
  user_id: string;
  medication_id: string;
  log_date: string;
  taken: boolean;
  created_at: string;
}

export interface JournalEntry {
  id: string;
  user_id: string;
  body: string;
  created_at: string;
  updated_at: string;
}
