export const config = {
  app: {
    name: "AuraTracker",
    description: "A personal seizure, recovery, and treatment-response journal",
    version: "0.1.0",
  },
  supabase: {
    url: process.env.NEXT_PUBLIC_SUPABASE_URL!,
    anonKey: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
  },
};
