"use client";

import Nav from "@/components/Nav";

export default function CheckIn() {
  return (
    <main className="min-h-screen bg-ink">
      <Nav />
      <div className="max-w-4xl mx-auto px-4 py-8">
        <h1 className="font-display text-3xl mb-6">Daily Check-in</h1>
        <div className="card p-6">
          <p className="text-fog">Daily check-in form coming soon...</p>
        </div>
      </div>
    </main>
  );
}
