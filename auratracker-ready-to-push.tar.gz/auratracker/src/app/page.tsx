"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import Nav from "@/components/Nav";
import { supabase } from "@/lib/supabase/client";
import type { SeizureEvent, DailyLog } from "@/lib/types/database";

export default function Dashboard() {
  const [seizures, setSeizures] = useState<SeizureEvent[]>([]);
  const [logs, setLogs] = useState<DailyLog[]>([]);
  const [checkedInToday, setCheckedInToday] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const since = new Date();
      since.setDate(since.getDate() - 30);

      const [
        { data: sz },
        { data: dl },
      ] = await Promise.all([
        supabase
          .from("seizure_events")
          .select("id,occurred_at,seizure_type,severity,duration_seconds,triggers")
          .gte("occurred_at", since.toISOString())
          .order("occurred_at", { ascending: false }),
        supabase
          .from("daily_logs")
          .select("log_date,sleep_hours,mood,pain")
          .gte("log_date", since.toISOString().slice(0, 10))
          .order("log_date", { ascending: false }),
      ]);

      setSeizures(sz ?? []);
      setLogs(dl ?? []);

      const today = new Date().toISOString().slice(0, 10);
      const checkedToday = (dl ?? []).some((log) => log.log_date === today);
      setCheckedInToday(checkedToday);
      setLoading(false);
    })();
  }, []);

  return (
    <main className="min-h-screen bg-ink">
      <Nav />
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="font-display text-4xl tracking-tight mb-2">aura</h1>
          <p className="text-fog text-sm">Your seizure & recovery journal.</p>
        </div>

        {loading ? (
          <p className="text-fog">Loading...</p>
        ) : (
          <div className="grid gap-6 md:grid-cols-2">
            {/* Quick stats */}
            <div className="card p-6">
              <h2 className="label">Last 30 days</h2>
              <div className="space-y-3">
                <div>
                  <p className="text-3xl font-display">{seizures.length}</p>
                  <p className="text-fog text-sm">events logged</p>
                </div>
                <div>
                  <p className="text-3xl font-display">{logs.length}</p>
                  <p className="text-fog text-sm">daily check-ins</p>
                </div>
              </div>
            </div>

            {/* Quick actions */}
            <div className="card p-6 flex flex-col gap-3">
              <h2 className="label">Quick actions</h2>
              <Link href="/log/seizure" className="btn-primary">
                Log seizure event
              </Link>
              <Link
                href={checkedInToday ? "/calendar" : "/checkin"}
                className="btn-ghost"
              >
                {checkedInToday ? "View today" : "Check in today"}
              </Link>
            </div>

            {/* Recent seizures */}
            {seizures.length > 0 && (
              <div className="md:col-span-2 card p-6">
                <h2 className="label mb-4">Recent events</h2>
                <div className="space-y-3">
                  {seizures.slice(0, 5).map((s) => (
                    <div key={s.id} className="flex justify-between items-start">
                      <div>
                        <p className="text-sm text-snow">
                          {s.seizure_type || "Event"} • Severity{" "}
                          {s.severity ?? "?"}
                        </p>
                        <p className="text-xs text-fog">
                          {new Date(s.occurred_at).toLocaleString()}
                        </p>
                      </div>
                      {s.duration_seconds && (
                        <p className="text-xs text-fog">{s.duration_seconds}s</p>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </main>
  );
}
