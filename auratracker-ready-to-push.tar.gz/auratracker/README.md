# AuraTracker

A personal seizure, recovery, and treatment-response journal for managing health events and improving healthcare conversations.

## Overview

AuraTracker is a web application built to help people with epilepsy and seizure disorders track symptoms, medications, daily health patterns, and recovery progress. It provides tools to organize health information so users can walk into medical appointments with clarity and better communicate with their care team.

**Important:** AuraTracker is not a medical device and does not provide medical advice. It is a personal journaling and tracking tool designed to complement, not replace, medical care. Always consult with your healthcare provider for medical decisions.

## Features

- **Seizure Logging**: Record seizure events with type, duration, severity, and triggers
- **Daily Check-ins**: Track sleep, mood, pain, stress, and other daily factors
- **Medication Management**: Keep a record of medications and track adherence
- **Journal Entries**: Write free-form notes about health and recovery
- **Calendar View**: Visualize patterns and events over time
- **Health Reports**: Generate summaries for healthcare appointments
- **Privacy-First**: Your data stays in your Supabase project

## Tech Stack

- **Frontend**: Next.js 14, React 18, TypeScript, Tailwind CSS
- **Backend**: Supabase (PostgreSQL, Auth)
- **Hosting**: Vercel (or self-hosted via Docker)

## Getting Started

### Prerequisites

- Node.js 18+ 
- npm or yarn
- A Supabase account (free tier works)

### Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/prism-ent/auratracker.git
   cd auratracker
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up Supabase**
   - Create a new Supabase project at https://supabase.com
   - Copy your project URL and anon key
   - Run the database schema setup (see below)

4. **Create `.env.local`**
   ```bash
   cp .env.example .env.local
   ```
   Add your Supabase credentials:
   ```
   NEXT_PUBLIC_SUPABASE_URL=your_project_url
   NEXT_PUBLIC_SUPABASE_ANON_KEY=your_anon_key
   ```

5. **Set up the database**
   - Open Supabase SQL Editor for your project
   - Run the SQL migrations in `/docs/migrations/init.sql`

6. **Start the dev server**
   ```bash
   npm run dev
   ```
   Open http://localhost:3000

## Database Schema

AuraTracker uses five core tables:

### `seizure_events`
Tracks individual seizure or treatment events.
- `id`, `user_id`, `occurred_at`, `duration_seconds`
- `seizure_type`, `severity` (1-5), `triggers` (array), `notes`

### `daily_logs`
Daily health check-ins.
- `id`, `user_id`, `log_date`
- `sleep_hours`, `sleep_quality`, `mood`, `pain`, `stress`
- `caffeine`, `alcohol`, `exercise`, `notes`

### `medications`
Medication inventory.
- `id`, `user_id`, `name`, `dose`, `schedule`, `active`

### `med_logs`
Medication adherence tracking.
- `id`, `user_id`, `medication_id`, `log_date`, `taken`

### `journal_entries`
Free-form journaling.
- `id`, `user_id`, `body`, `created_at`, `updated_at`

## Project Structure

```
src/
├── app/                    # Next.js App Router pages
│   ├── layout.tsx         # Root layout
│   ├── page.tsx           # Dashboard
│   ├── journal/           # Journal page
│   ├── calendar/          # Calendar view
│   ├── meds/              # Medication management
│   ├── report/            # Health reports
│   ├── checkin/           # Daily check-in
│   └── log/seizure/       # Seizure logging
├── components/            # React components
├── lib/
│   ├── supabase/         # Supabase client
│   ├── types/            # TypeScript types
│   └── config.ts         # Configuration
└── styles/               # Global styles
```

## Contributing

Contributions are welcome! This project aims to be accessible and helpful to people managing seizure disorders and health tracking.

### Areas We'd Love Help With

- **Accessibility**: Ensuring the app works well for all users
- **Usability**: Simplifying health data entry and insights
- **Features**: New tracking dimensions or report types
- **Privacy**: Security reviews and data protection improvements
- **Documentation**: Guides, examples, or deployment instructions

See [CONTRIBUTING.md](./CONTRIBUTING.md) for guidelines.

## Deployment

### Vercel (Recommended)

1. Push to GitHub
2. Connect your repository to Vercel
3. Add environment variables for Supabase
4. Deploy

### Self-Hosting with Docker

```bash
docker build -t auratracker .
docker run -p 3000:3000 \
  -e NEXT_PUBLIC_SUPABASE_URL=your_url \
  -e NEXT_PUBLIC_SUPABASE_ANON_KEY=your_key \
  auratracker
```

### Oracle Cloud (Free Tier)

See deployment docs for self-hosting on Oracle Cloud Always Free instances.

## Data Privacy & Security

- All authentication is handled by Supabase
- Data is encrypted in transit (HTTPS) and at rest
- Row-level security (RLS) ensures users only see their own data
- No third-party analytics or tracking
- You own your data and can export/delete anytime

## License

MIT License — see [LICENSE](./LICENSE) for details.

## Disclaimer

**AuraTracker is intended for personal use and health tracking only.** It does not:
- Diagnose, treat, or prevent any disease or condition
- Replace professional medical advice
- Provide emergency medical services

Always consult a healthcare provider for medical concerns.

## Acknowledgments

Built with ❤️ for my dad and others managing seizure disorders. Special thanks to the Supabase and Next.js communities.

---

**Questions?** Open an issue or start a discussion on GitHub.
