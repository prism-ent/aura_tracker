# Deployment Guide

## Quick Start: Vercel (Recommended)

Vercel is the fastest way to deploy AuraTracker:

1. **Push to GitHub**
   ```bash
   git add .
   git commit -m "Initial commit"
   git push origin main
   ```

2. **Connect to Vercel**
   - Go to https://vercel.com
   - Sign in with GitHub
   - Import your `auratracker` repository
   - Vercel will auto-detect Next.js

3. **Add Environment Variables**
   In Vercel project settings → Environment Variables, add:
   ```
   NEXT_PUBLIC_SUPABASE_URL=your_project_url
   NEXT_PUBLIC_SUPABASE_ANON_KEY=your_anon_key
   ```

4. **Deploy**
   - Click "Deploy"
   - Done! Your app is live

## Self-Hosting on Oracle Cloud (Free Tier)

Coming soon with detailed setup guide.

## Docker Deployment

```dockerfile
# Dockerfile
FROM node:18-alpine

WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production

COPY . .
RUN npm run build

ENV NODE_ENV=production
EXPOSE 3000

CMD ["npm", "start"]
```

Build and run:
```bash
docker build -t auratracker .
docker run -p 3000:3000 \
  -e NEXT_PUBLIC_SUPABASE_URL=your_url \
  -e NEXT_PUBLIC_SUPABASE_ANON_KEY=your_key \
  auratracker
```

## Database Setup

### For Supabase

1. Create a new Supabase project
2. In SQL Editor, run the migrations:

```sql
-- Users are managed by Supabase Auth

CREATE TABLE seizure_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  occurred_at TIMESTAMP WITH TIME ZONE NOT NULL,
  duration_seconds INTEGER,
  seizure_type TEXT,
  severity INTEGER,
  triggers TEXT[] DEFAULT '{}',
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

CREATE TABLE daily_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  log_date DATE NOT NULL,
  sleep_hours NUMERIC,
  sleep_quality INTEGER,
  stress INTEGER,
  mood INTEGER,
  pain INTEGER,
  took_meds BOOLEAN DEFAULT true,
  caffeine BOOLEAN DEFAULT false,
  alcohol BOOLEAN DEFAULT false,
  exercise BOOLEAN DEFAULT false,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

CREATE TABLE medications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  dose TEXT,
  schedule TEXT,
  active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

CREATE TABLE med_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  medication_id UUID NOT NULL REFERENCES medications(id) ON DELETE CASCADE,
  log_date DATE NOT NULL,
  taken BOOLEAN NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

CREATE TABLE journal_entries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  body TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable Row-Level Security
ALTER TABLE seizure_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE daily_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE medications ENABLE ROW LEVEL SECURITY;
ALTER TABLE med_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE journal_entries ENABLE ROW LEVEL SECURITY;

-- RLS Policies: Users can only see their own data
CREATE POLICY "Users see own seizure events" ON seizure_events
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users insert own seizure events" ON seizure_events
  FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Repeat for other tables...
```

3. Create an Anon (public) key in Authentication → API Keys
4. Add it to your `.env.local`

## Monitoring & Maintenance

### Logs
- Vercel: Dashboard → Logs
- Supabase: SQL Editor or real-time logs

### Backups
- Supabase: Automated daily backups (free tier)
- Export regularly for safety

### Performance
- Monitor response times in Vercel
- Check database query performance in Supabase

## Troubleshooting

**Auth not working:**
- Verify Supabase URL and key are correct
- Check browser console for errors
- Ensure RLS policies are set up

**Data not loading:**
- Check Supabase connection in browser network tab
- Verify RLS policies allow access
- Review Supabase logs

**Build fails:**
- Clear `.next` directory: `rm -rf .next`
- Reinstall: `rm -rf node_modules && npm install`
- Check Node version: `node --version` (need 18+)

---

Need help? Open an issue on GitHub.
